anonymity.metrics package
=========================

Submodules
----------

anonymity.metrics.data\_utility\_metrics module
-----------------------------------------------

.. automodule:: anonymity.metrics.data_utility_metrics
   :members:
   :undoc-members:
   :show-inheritance:

anonymity.metrics.efficiency\_metrics module
--------------------------------------------

.. automodule:: anonymity.metrics.efficiency_metrics
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: anonymity.metrics
   :members:
   :undoc-members:
   :show-inheritance:
